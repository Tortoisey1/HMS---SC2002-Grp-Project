package menu;

import entities.User;

public class ReplenishStockMenu extends Menu {
    @Override
    public void printMenu(User user) {

    }
    public void printMenu() {
        
    }
}
