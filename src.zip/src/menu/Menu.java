package menu;

import entities.User;

public abstract class Menu {
    public abstract void printMenu(User user);
    public void printMenu(){};
}
