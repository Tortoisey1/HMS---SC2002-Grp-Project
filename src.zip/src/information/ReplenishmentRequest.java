//package information;
//
//import entities.Pharmacist;
//import information.id.PharmacistID;
//
//public class ReplenishmentRequest {
//    private PharmacistID id;
//    private String medicineName;
//    private int amount;
//
//    public ReplenishmentRequest(PharmacistID id, String medicineName, int amount) {
//        this.id = id;
//        this.medicineName = medicineName;
//        this.amount = amount;
//    }
//
//    public String getMedicineName() {
//        return medicineName;
//    }
//
//    public void setMedicineName(String medicineName) {
//        this.medicineName = medicineName;
//    }
//
//    public int getAmount() {
//        return amount;
//    }
//
//    public void setAmount(int amount) {
//        this.amount = amount;
//    }
//
//    public PharmacistID getId() {
//        return id;
//    }
//
//    public void setId(PharmacistID id) {
//        this.id = id;
//    }
//
//}
