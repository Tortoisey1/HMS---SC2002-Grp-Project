package exceptions;

public class NotInSystem extends Exception {
    public NotInSystem(String message) {
        super(message);
    }
}
