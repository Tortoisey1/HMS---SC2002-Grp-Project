package exceptions;

public class StaffExistException extends Exception {
    public StaffExistException(String message) {
        super(message);
    }
}
