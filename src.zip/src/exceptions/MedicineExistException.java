package exceptions;

public class MedicineExistException extends Exception{
    public MedicineExistException(String message) {
        super(message);
    }
}
