package entities;

public class Diagnosis {

}
