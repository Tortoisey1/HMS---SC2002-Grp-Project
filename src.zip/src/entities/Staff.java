package entities;

import information.UserInformation;

public class Staff extends User {

    public Staff(UserInformation userInformation) {
        super(userInformation);
    }

}
