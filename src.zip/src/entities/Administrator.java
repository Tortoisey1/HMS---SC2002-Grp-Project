package entities;

import information.UserInformation;

public class Administrator extends Staff {

    public Administrator(UserInformation userInformation) {
        super(userInformation);
    }
}
