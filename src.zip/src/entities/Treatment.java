package entities;

public class Treatment {

}
