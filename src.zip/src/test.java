import menu.medicalServiceMenu;

public class test {
    public static void main(String[] args) {
        medicalServiceMenu.printMenu();
    }
}
