package enums;

public enum AppointmentStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED,
    PENDING
}
