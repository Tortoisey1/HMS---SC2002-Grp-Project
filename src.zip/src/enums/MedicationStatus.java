package enums;

public enum MedicationStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
