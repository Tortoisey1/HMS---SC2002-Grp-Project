package enums;

public enum MedicalService {
    XRAY,
    CONSULTATION,
    BLOOD_TEST,
    MRI,
    ULTRASOUND,
    VACCINATION,
    PHYSIOTHERAPY
}
