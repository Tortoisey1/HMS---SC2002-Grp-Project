package enums;

public enum Gender {
    MALE,
    FEMALE
}
