package services.pharmacist;

import enums.AppointmentStatus;
import information.medical.AppointmentOutcomeRecord;

public class AppointmentOutcomeRecordPharmacistService {
    public void updatePrescriptionStatus(AppointmentOutcomeRecord appointmentOutcomeRecord,AppointmentStatus appointmentStatus){
        
    }
}
