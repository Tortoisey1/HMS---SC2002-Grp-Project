package update;

public interface UpdateService {
    public void add();

    public void remove();

    public void update(Object object);
}
