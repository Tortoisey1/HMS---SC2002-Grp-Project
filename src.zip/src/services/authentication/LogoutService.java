package services.authentication;

public class LogoutService {

}
