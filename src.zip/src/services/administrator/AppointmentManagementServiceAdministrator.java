//import information.AppointmentInformation;
//
//public class AppointmentManagementServiceAdministrator {
//    private List<AppointmentInformation> appointments;
//
//    public void display() {
//        for (AppointmentInformation appointmentInformation : appointments) {
//            System.out.println(appointmentInformation);
//        }
//    }
//}
