

//public class AdministratorService {
//    private InventoryManagementService inventoryManagementService;
//    private StaffManagementService staffManagementService;
//
//}
